#Gotcha!
#Python 2.7
import turtle
import os
import time


#set up screen
wn = turtle.Screen()
wn.bgcolor("black")
wn.setup(800,800)
wn.title("Gotcha!")
wn.bgpic('park4.gif')

#register gifs
turtle.register_shape('bird_3.gif')
turtle.register_shape('bird_2.gif')


#draw border
border_pen = turtle.Turtle()
border_pen.speed(0)
border_pen.color("white")
border_pen.penup()
border_pen.setposition(-300,-300)
border_pen.pendown()
border_pen.pensize(3)
for side in range(4):
    border_pen.fd(600)
    border_pen.lt(90)
border_pen.hideturtle()


#create bystander
bystander = turtle.Turtle()
bystander.penup()
bystander.setposition(10, -120)
bystander.hideturtle()
bystander.color("purple")
bystander.write("<_<", font=("Calibri", 24, "bold"))
bystander.speed(0)

#bystander look around
time.sleep(1)
bystander.clear()
bystander.write(">_>", font=("Calibri", 24, "bold"))
time.sleep(1)
bystander.clear()
bystander.write("<_<", font=("Calibri", 24, "bold"))
time.sleep(1)
bystander.clear()
bystander.write(">_>", font=("Calibri", 24, "bold"))
time.sleep(1)
bystander.clear()
bystander.write("^_^", font=("Calibri", 24, "bold"))

#create flyer
flyer = turtle.Turtle()
flyer.penup()
flyer.setposition(-270, 250)
flyer.color("red")
flyer.shape("bird_3.gif")
flyer.speed(15)

flyerspeed = 30

#main loop
while True:
    x = flyer.xcor()
    x += flyerspeed
    flyer.setx(x)

    if flyer.xcor() > -260:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -250:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -240:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -230:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -220:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -210:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)
	
    if flyer.xcor() > -200:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -190:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -180:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -170:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -160:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -150:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -140:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -130:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -120:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -110:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -100:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -90:
        y = flyer.ycor()
        y -= 5
        flyer.sety(y)

    if flyer.xcor() > -90:
        break

#gotcha
flyer.shape("bird_2.gif")
flytext = turtle.Turtle()
flytext.penup()
flytext.setposition(-90,-70)
flytext.hideturtle()
flytext.color("red")
flytext.write("Boo!", font=("Arial", 24, "bold"))

bystander.clear()
bystander.write("O_O", font=("Calibri", 24, "bold"))
time.sleep(2)
bystander.clear()
flytext.clear()
bystander.write("X_X", font=("Calibri", 24, "bold"))
time.sleep(1)
flytext.write("hehehe", font=("Arial", 24, "bold"))


delay = input("Press enter to finish.")
